﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

/**
 * 
 */
class SPACETIMEDB_API FBinaryWriter
{
public:
	FBinaryWriter();

	void WriteU8(uint8 Value);
	void WriteI8(int8 Value);
	void WriteU16(uint16 Value);
	void WriteI16(int16 Value);
	void WriteU32(uint32 Value);
	void WriteI32(int32 Value);
	void WriteU64(uint64 Value);
	void WriteI64(int64 Value);
	void WriteBool(bool Value);
	void WriteF32(float Value);
	void WriteF64(double Value);
	void WriteString(const FString& Value);
	void WriteUInt8Array(const TArray<uint8>& Value);
	void WriteBytes(const TArray<uint8>& Value);

	// 128/256-bit support (as TArray<uint8> for now)
	void WriteU128(const TArray<uint8>& Value);
	void WriteI128(const TArray<uint8>& Value);
	void WriteU256(const TArray<uint8>& Value);
	void WriteI256(const TArray<uint8>& Value);

	const TArray<uint8>& GetBuffer() const;

private:
	TArray<uint8> Buffer;
};
