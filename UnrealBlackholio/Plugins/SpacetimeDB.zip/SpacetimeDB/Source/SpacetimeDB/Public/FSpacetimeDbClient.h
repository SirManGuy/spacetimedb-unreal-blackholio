﻿#pragma once

#include "CoreMinimal.h"
#include "IWebSocket.h"
#include "Containers/Queue.h"
#include "HAL/Runnable.h"
#include "JsonObjectConverter.h"

/**
 * Represents a parsed message received from SpacetimeDB.
 */
struct FPendingSpacetimeEvent
{
	FString Type;
	TSharedPtr<FJsonObject> Payload;
};

/**
 * Low-level SpacetimeDB client:
 * - Handles WebSocket connection/reconnection logic
 * - Parses JSON messages into PendingEvents
 * - Runs in background thread and synchronizes with main thread
 */
class FSpacetimeDbClient : public FRunnable
{
public:
	FSpacetimeDbClient(const FString& InUri, const FString& InModule, const FString& InToken);
	virtual ~FSpacetimeDbClient();

	virtual bool Init() override;
	virtual uint32 Run() override;
	virtual void Stop() override;
	virtual void Exit() override;

	void DrainPendingEvents(); // Game thread: drains and dispatches events
	void SendMessage(const FString& JsonPayload);
	void RequestReconnect();

private:
	void PerformConnect();
	void HandleRawMessage(const FString& RawJson);
	FPendingSpacetimeEvent ParseEvent(const TSharedPtr<FJsonObject>& JsonObj);

	TSharedPtr<IWebSocket> Socket;
	FRunnableThread* Thread;
	FThreadSafeBool bRunThread;
	FCriticalSection QueueMutex;

	TQueue<FPendingSpacetimeEvent, EQueueMode::Mpsc> PendingEvents;

	FString Uri;
	FString ModuleName;
	FString AuthToken;

	int32 ReconnectAttempts;
	double LastReconnectTime;
	double ReconnectDelay;

	bool bConnected;
};
