﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

/**
 * 
 */
class SPACETIMEDB_API FBinaryReader
{
public:
	FBinaryReader(const TArray<uint8>& InBuffer);

	uint8 ReadU8();
	int8 ReadI8();
	uint16 ReadU16();
	int16 ReadI16();
	uint32 ReadU32();
	int32 ReadI32();
	uint64 ReadU64();
	int64 ReadI64();
	bool ReadBool();
	float ReadF32();
	double ReadF64();
	FString ReadString();
	TArray<uint8> ReadUInt8Array();
	TArray<uint8> ReadBytes(int32 Length);

	// 128/256-bit support (as TArray<uint8> for now)
	TArray<uint8> ReadU128();
	TArray<uint8> ReadI128();
	TArray<uint8> ReadU256();
	TArray<uint8> ReadI256();

	int32 GetOffset() const;

private:
	const TArray<uint8>& Buffer;
	int32 Offset;
};
