﻿#include "FSpacetimeDbClient.h"
#include "WebSocketsModule.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonSerializer.h"
#include "Misc/DateTime.h"
#include "HAL/PlatformProcess.h"

FSpacetimeDbClient::FSpacetimeDbClient(const FString& InUri, const FString& InModule, const FString& InToken)
    : Uri(InUri)
    , ModuleName(InModule)
    , AuthToken(InToken)
    , Thread(nullptr)
    , bRunThread(true)
    , ReconnectAttempts(0)
    , LastReconnectTime(0)
    , ReconnectDelay(1.0)
    , bConnected(false)
{
    Thread = FRunnableThread::Create(this, TEXT("FSpacetimeDbClientThread"));
}

FSpacetimeDbClient::~FSpacetimeDbClient()
{
    bRunThread = false;

    if (Socket.IsValid())
    {
        Socket->Close();
        Socket.Reset();
    }

    if (Thread)
    {
        Thread->Kill(true);
        delete Thread;
    }
}

bool FSpacetimeDbClient::Init()
{
    return true;
}

uint32 FSpacetimeDbClient::Run()
{
    while (bRunThread)
    {
        if (!Socket.IsValid() || !Socket->IsConnected())
        {
            double CurrentTime = FPlatformTime::Seconds();
            if (CurrentTime - LastReconnectTime >= ReconnectDelay)
            {
                PerformConnect();
                LastReconnectTime = CurrentTime;
                ReconnectDelay = FMath::Clamp(ReconnectDelay * 2.0, 1.0, 30.0);
            }
        }

        FPlatformProcess::Sleep(0.01f);
    }
    return 0;
}

void FSpacetimeDbClient::Stop()
{
    bRunThread = false;
    if (Socket.IsValid())
    {
        Socket->Close();
        Socket.Reset();
    }
}

void FSpacetimeDbClient::Exit()
{
}

void FSpacetimeDbClient::PerformConnect()
{
    FWebSocketsModule& WebSocketModule = FModuleManager::LoadModuleChecked<FWebSocketsModule>("WebSockets");

    FString FullUri = FString::Printf(TEXT("%s/v1/database/%s/subscribe?token=%s"), *Uri, *ModuleName, *AuthToken);
    Socket = WebSocketModule.CreateWebSocket(FullUri, TEXT("spacetime"));

    Socket->OnConnected().AddLambda([this]()
    {
        bConnected = true;
        ReconnectAttempts = 0;
        ReconnectDelay = 1.0;

        FPendingSpacetimeEvent Event;
        Event.Type = TEXT("Connected");
        QueueMutex.Lock();
        PendingEvents.Enqueue(Event);
        QueueMutex.Unlock();
    });

    Socket->OnMessage().AddLambda([this](const FString& Message)
    {
        HandleRawMessage(Message);
    });

    Socket->OnConnectionError().AddLambda([this](const FString& Error)
    {
        bConnected = false;

        FPendingSpacetimeEvent Event;
        Event.Type = TEXT("Error");
        Event.Payload = MakeShared<FJsonObject>();
        Event.Payload->SetStringField("error", Error);

        QueueMutex.Lock();
        PendingEvents.Enqueue(Event);
        QueueMutex.Unlock();
    });

    Socket->OnClosed().AddLambda([this](int32, const FString&, bool)
    {
        bConnected = false;

        FPendingSpacetimeEvent Event;
        Event.Type = TEXT("Closed");

        QueueMutex.Lock();
        PendingEvents.Enqueue(Event);
        QueueMutex.Unlock();
    });

    Socket->Connect();
}

void FSpacetimeDbClient::HandleRawMessage(const FString& RawJson)
{
    TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(RawJson);
    TSharedPtr<FJsonObject> RootObject;
    if (FJsonSerializer::Deserialize(Reader, RootObject))
    {
        FPendingSpacetimeEvent Parsed = ParseEvent(RootObject);
        QueueMutex.Lock();
        PendingEvents.Enqueue(Parsed);
        QueueMutex.Unlock();
    }
}

FPendingSpacetimeEvent FSpacetimeDbClient::ParseEvent(const TSharedPtr<FJsonObject>& JsonObj)
{
    FPendingSpacetimeEvent Event;
    FString TypeValue;
    if (JsonObj->TryGetStringField(TEXT("type"), TypeValue))
    {
        Event.Type = TypeValue;
    }
    else
    {
        Event.Type = TEXT("Unknown");
        Event.Payload = JsonObj;
    }

    return Event;
}

void FSpacetimeDbClient::DrainPendingEvents()
{
    FPendingSpacetimeEvent Event;
    while (PendingEvents.Dequeue(Event))
    {
        // Dispatch to owner or subsystem as needed
        // Example:
        // USpacetimeDBConnection->HandleSpacetimeEvent(Event);
    }
}

void FSpacetimeDbClient::SendMessage(const FString& JsonPayload)
{
    if (Socket.IsValid() && Socket->IsConnected())
    {
        Socket->Send(JsonPayload);
    }
}

void FSpacetimeDbClient::RequestReconnect()
{
    if (Socket.IsValid())
    {
        Socket->Close();
        Socket.Reset();
    }
    ReconnectDelay = 1.0;
}
