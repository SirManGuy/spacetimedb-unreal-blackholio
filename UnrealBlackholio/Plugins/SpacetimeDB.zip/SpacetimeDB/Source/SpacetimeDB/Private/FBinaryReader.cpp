﻿#include "FBinaryReader.h"

FBinaryReader::FBinaryReader(const TArray<uint8>& InBuffer)
    : Buffer(InBuffer), Offset(0)
{}

uint8 FBinaryReader::ReadU8()
{
    return Buffer[Offset++];
}

int8 FBinaryReader::ReadI8()
{
    return static_cast<int8>(Buffer[Offset++]);
}

uint16 FBinaryReader::ReadU16()
{
    uint16 Value;
    FMemory::Memcpy(&Value, &Buffer[Offset], sizeof(uint16));
    Offset += sizeof(uint16);
    return Value;
}

int16 FBinaryReader::ReadI16()
{
    int16 Value;
    FMemory::Memcpy(&Value, &Buffer[Offset], sizeof(int16));
    Offset += sizeof(int16);
    return Value;
}

uint32 FBinaryReader::ReadU32()
{
    uint32 Value;
    FMemory::Memcpy(&Value, &Buffer[Offset], sizeof(uint32));
    Offset += sizeof(uint32);
    return Value;
}

int32 FBinaryReader::ReadI32()
{
    int32 Value;
    FMemory::Memcpy(&Value, &Buffer[Offset], sizeof(int32));
    Offset += sizeof(int32);
    return Value;
}

uint64 FBinaryReader::ReadU64()
{
    uint64 Value;
    FMemory::Memcpy(&Value, &Buffer[Offset], sizeof(uint64));
    Offset += sizeof(uint64);
    return Value;
}

int64 FBinaryReader::ReadI64()
{
    int64 Value;
    FMemory::Memcpy(&Value, &Buffer[Offset], sizeof(int64));
    Offset += sizeof(int64);
    return Value;
}

bool FBinaryReader::ReadBool()
{
    return Buffer[Offset++] != 0;
}

float FBinaryReader::ReadF32()
{
    float Value;
    FMemory::Memcpy(&Value, &Buffer[Offset], sizeof(float));
    Offset += sizeof(float);
    return Value;
}

double FBinaryReader::ReadF64()
{
    double Value;
    FMemory::Memcpy(&Value, &Buffer[Offset], sizeof(double));
    Offset += sizeof(double);
    return Value;
}

FString FBinaryReader::ReadString()
{
    uint32 Length = ReadU32();
    FString Result = FString(UTF8_TO_TCHAR(reinterpret_cast<const char*>(&Buffer[Offset])), Length);
    Offset += Length;
    return Result;
}

TArray<uint8> FBinaryReader::ReadUInt8Array()
{
    uint32 Length = ReadU32();
    TArray<uint8> Out;
    Out.Append(&Buffer[Offset], Length);
    Offset += Length;
    return Out;
}

TArray<uint8> FBinaryReader::ReadBytes(int32 Length)
{
    TArray<uint8> Out;
    Out.Append(&Buffer[Offset], Length);
    Offset += Length;
    return Out;
}

// For 128/256-bit, just return as byte arrays for now
TArray<uint8> FBinaryReader::ReadU128() { return ReadBytes(16); }
TArray<uint8> FBinaryReader::ReadI128() { return ReadBytes(16); }
TArray<uint8> FBinaryReader::ReadU256() { return ReadBytes(32); }
TArray<uint8> FBinaryReader::ReadI256() { return ReadBytes(32); }

int32 FBinaryReader::GetOffset() const { return Offset; }