﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "FBinaryWriter.h"
FBinaryWriter::FBinaryWriter()
{
    Buffer.Reserve(256);
}

void FBinaryWriter::WriteU8(uint8 Value)
{
    Buffer.Add(Value);
}

void FBinaryWriter::WriteI8(int8 Value)
{
    Buffer.Add(static_cast<uint8>(Value));
}

void FBinaryWriter::WriteU16(uint16 Value)
{
    Buffer.Append(reinterpret_cast<uint8*>(&Value), sizeof(uint16));
}

void FBinaryWriter::WriteI16(int16 Value)
{
    Buffer.Append(reinterpret_cast<uint8*>(&Value), sizeof(int16));
}

void FBinaryWriter::WriteU32(uint32 Value)
{
    Buffer.Append(reinterpret_cast<uint8*>(&Value), sizeof(uint32));
}

void FBinaryWriter::WriteI32(int32 Value)
{
    Buffer.Append(reinterpret_cast<uint8*>(&Value), sizeof(int32));
}

void FBinaryWriter::WriteU64(uint64 Value)
{
    Buffer.Append(reinterpret_cast<uint8*>(&Value), sizeof(uint64));
}

void FBinaryWriter::WriteI64(int64 Value)
{
    Buffer.Append(reinterpret_cast<uint8*>(&Value), sizeof(int64));
}

void FBinaryWriter::WriteBool(bool Value)
{
    Buffer.Add(Value ? 1 : 0);
}

void FBinaryWriter::WriteF32(float Value)
{
    Buffer.Append(reinterpret_cast<uint8*>(&Value), sizeof(float));
}

void FBinaryWriter::WriteF64(double Value)
{
    Buffer.Append(reinterpret_cast<uint8*>(&Value), sizeof(double));
}

void FBinaryWriter::WriteString(const FString& Value)
{
    FTCHARToUTF8 Converter(*Value);
    WriteU32(Converter.Length());
    Buffer.Append(reinterpret_cast<const uint8*>(Converter.Get()), Converter.Length());
}

void FBinaryWriter::WriteUInt8Array(const TArray<uint8>& Value)
{
    WriteU32(Value.Num());
    Buffer.Append(Value);
}

void FBinaryWriter::WriteBytes(const TArray<uint8>& Value)
{
    Buffer.Append(Value);
}

// For 128/256-bit, just write as byte arrays for now
void FBinaryWriter::WriteU128(const TArray<uint8>& Value) { Buffer.Append(Value); }
void FBinaryWriter::WriteI128(const TArray<uint8>& Value) { Buffer.Append(Value); }
void FBinaryWriter::WriteU256(const TArray<uint8>& Value) { Buffer.Append(Value); }
void FBinaryWriter::WriteI256(const TArray<uint8>& Value) { Buffer.Append(Value); }

const TArray<uint8>& FBinaryWriter::GetBuffer() const { return Buffer; }